clc; close all; clear variables

%% CS 830 Final Project
% Matthew Westbrook
dt = 0.01;
s = 5;
R = 11;

first_grid_map = csvread('first_grid.csv');
final_grid_map = csvread('final_grid.csv');
grid_updates = csvread('real_time.csv');
robot_path = csvread('robot_path.csv');
first_path = csvread('first_path.csv');
final_path = csvread('final_path.csv');

n = 1;
points = [];
for i = 1:length(robot_path(:,1))
    if robot_path(i,1) == -1
        p(n).path = points;
        n = n+1;
        points = [];
    else
        points(end+1,:) = [robot_path(i,1) robot_path(i,2)];
    end
end
p(n).path = points;

add = [];
remove = [];
for i = 1:length(grid_updates(:,1))
    if grid_updates(i,1) == 1
        add(end+1,:) = [0 grid_updates(i,2) grid_updates(i,3)];
    else
        remove(end+1,:) = [0 grid_updates(i,2) grid_updates(i,3)];
    end
end

% Initial
figure
hold on
for i = 1:length(first_path(:,1))
    plot([first_path(i,1) first_path(i,3)], [first_path(i,2) first_path(i,4)],...
        'Color', [.7 .7 .7]) 
end
plot(p(1).path(end,1), p(1).path(end,2),'b*','MarkerSize',10)
plot(p(1).path(1,1), p(1).path(1,2),'g*','MarkerSize',10)
plot(p(1).path(:,1), p(1).path(:,2),'r','Linewidth',2);
for i = 1:length(first_grid_map(:,1)) 
    rectangle('Position',[first_grid_map(i,1),first_grid_map(i,2),1,1],...
        'FaceColor',[0 0 0])
end
title('Initial Tree')

% Final
figure
hold on
for i = 1:length(final_path(:,1))
    plot([final_path(i,1) final_path(i,3)], [final_path(i,2) final_path(i,4)],...
        'Color', [.7 .7 .7]) 
end
plot(p(1).path(end,1), p(1).path(end,2),'b*','MarkerSize',10)
for i = 1:length(final_grid_map(:,1)) 
    rectangle('Position',[final_grid_map(i,1),final_grid_map(i,2),1,1],...
        'FaceColor',[0 0 0])
end
title('Final Tree')

% Shrinking ball radius
figure
eps = .02;
delta = 3;
lam = 6000;
gamd = 1;
D = 2;
V = linspace(2,20000);
r = ((lam/gamd)*log(V)./V).^(1/D);
a = find(r < delta, 1);
plot(V,r,'b', V,delta+V*0,'r', [0, V(a:end)], [delta, r(a:end)],'m-.','Linewidth',2)
xlabel('|V|')
ylabel('units')
ylim([0 6.5])
title('Shrinking Ball Radius')
legend('f(|V|)', '\delta', 'r')
grid on
