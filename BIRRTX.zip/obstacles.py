import math
import numpy as np

import graph
import grid
import constants

# Matthew Westbrook

# Handles checking for obstacles and adding/removing as neccessary

def check_obstacles(C, blocked, unknown_loc, unknown, Q, v_bot, v_cell, e_cell, 
		loc, e_blocked, v_loc, v_info, v_orphan, r, eoi, eoo, eri, ero):
	# See if the obstacles have changed
	moving = True
	removed = []
	added = []
	d = np.linalg.norm(unknown_loc - loc, axis = 1)
	cells = np.argwhere(d < constants.R)
	for cell in cells:
		x = int(unknown_loc[cell,0])
		y = int(unknown_loc[cell,1])
		del unknown[y*C+x]
		if (y*C+x) in blocked:
			del blocked[y*C+x]
			moving = update_obstacles(C, Q, v_bot, blocked, v_cell, e_cell, y*C+x, e_blocked, v_loc, v_info, v_orphan, 
				r, eoi, eoo, eri, ero, False)
			removed.append([x,y])
		else:
			blocked[y*C+x] = 1
			moving = update_obstacles(C, Q, v_bot, blocked, v_cell, e_cell, y*C+x, e_blocked, v_loc, v_info, v_orphan, 
				r, eoi, eoo, eri, ero, True)
			added.append([x,y])
	unknown_loc = np.delete(unknown_loc, cells, axis = 0)
	return [removed, added, unknown_loc, moving]
		
def update_obstacles(C, Q, v_bot, blocked, v_cell, e_cell, loc, e_blocked, v_loc, v_info, v_orphan, 
		r, eoi, eoo, eri, ero, add_delete):
	# Update after discovering change in map
	moving = True
	if not add_delete:
		remove_obstacle(C, Q, loc, blocked, e_cell, e_blocked, v_loc, v_info, r, eoi, eoo, eri, ero, v_orphan)
		graph.reduce_inconsistency(Q, v_bot, v_info, eoi, eri, eoo, ero, r, v_orphan)
	else:
		moving = add_obstacle(Q, v_bot, loc, v_cell, e_cell, v_info, v_orphan, eoi, eoo, eri, ero)
		graph.propagate_descendents(Q, v_orphan, v_info, eoo, ero)
		graph.verify_queue(v_bot, v_info[v_bot][0], Q)
		graph.reduce_inconsistency(Q, v_bot, v_info, eoi, eri, eoo, ero,r, v_orphan)

def remove_obstacle(C, Q, loc, blocked, e_cell, e_blocked, v_loc, v_info, r, eoi, eoo, eri, ero, v_orphan):
	# Remove obstacle and repair graph
	for edge in e_blocked[loc]:
		u = edge[0]
		v = edge[1]
		[connected, interfered, cells] = graph.connect(C, blocked, v_loc[u,0], v_loc[u,1], 
			v_loc[v,0], v_loc[v,1])
		if connected:
			d = grid.ed(v_loc[u,0], v_loc[u,1], v_loc[v,0], v_loc[v,1])
			eoo[edge[0]][u] = d
			eri[edge[1]][edge[0]] = d
			ero[edge[1]][edge[0]] = d
			eoi[edge[0]][edge[1]] = d
			eoo[v][u] = d
			eri[u][v] = d
			ero[u][v] = d
			eoi[v][u] = d
			for cell in cells:
				e_cell[cell].append([v, u])
			graph.updateLMC(u, v_info, r, ero[u], eoo[u], eri[u], v_orphan)
			if v_info[u][1] != v_info[u][0]:
				graph.verify_queue(u, v_info[u][0], Q)
				
def add_obstacle(Q, v_bot, loc, v_cell, e_cell, v_info, v_orphan, eoi, eoo, eri, ero):
	# Add obstacle and repair graph
	for v in v_cell[loc]:
		v_info[v][4] = False
	moving = True	
	for edge in e_cell[loc]:
		v = edge[0]
		u = edge[1]
		if u in eoi[v]:
			del eoi[v][u]
			del eoo[v][u]
			if v_info[v][2] == u:
				graph.verify_orphan(Q, v, v_orphan)
				if (v_bot == u) or (v_bot == v):
					moving = False
		if u in eri[v]:
			del eri[v][u]
			del ero[v][u]
			if v_info[v][2] == u:
				graph.verify_orphan(Q, v, v_orphan)
				if (v_bot == u) or (v_bot == v):
					moving = False
		if v in eoi[u]:
			del eoi[u][v]
			del eoo[u][v]
			if v_info[u][2] == v:
				graph.verify_orphan(Q, u, v_orphan)
				if (v_bot == u) or (v_bot == v):
					moving = False
		if v in eri[u]:
			del eri[u][v]
			del ero[u][v]
			if v_info[u][2] == v:
				graph.verify_orphan(Q, u, v_orphan)
				if (v_bot == u) or (v_bot == v):
					moving = False
	return moving