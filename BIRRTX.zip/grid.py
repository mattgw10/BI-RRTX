import math
import numpy as np

import constants

# Matthew Westbrook

# Basic grid and distance functions

def ed(x1, y1, x2, y2):
	# Euclidean distance between two points
	return math.sqrt(pow(x1-x2,2)+pow(y1-y2,2))
	
def angle(x1, y1, x2, y2):
	# Slope from 1->2
	return math.atan2(y2-y1,x2-x1)
	
def near(v, v_loc, r):
	# Get vertices within r radius of new vertex
	d = np.linalg.norm(v_loc-v, axis = 1)
	return np.argwhere(d < r)

def nearest(v, v_loc):
	# Get vertices within r radius of new vertex
	d = np.linalg.norm(v_loc-v, axis = 1)
	return np.argmin(d)
	
def saturate(v, v_near):
	th = angle(v_near[0], v_near[1], v[0], v[1])
	return [v_near[0]+(constants.delta-1)*math.cos(th), v_near[1]+(constants.delta-1)*math.sin(th)]

def coord2grid(C, x, y):
	# Find grid cell corresponding to (x,y) coordinates
	gx = math.floor(x)
	gy = math.floor(y)
	return int(gy*C+gx)
	
def shrinking_ball(V):
	return min(math.pow((constants.lam/constants.gamd)*math.log(max(V,2))/V,1.0/constants.D), constants.delta)
	
def intersected_cells(C, x0, y0, x1, y1):
	# List of cells edge intersects
	cells = []
	
	th = angle(x0, y0, x1, y1)

	x = x0
	y = y0
	while abs(y1-y) > constants.DX:
		p = coord2grid(C, x, y)
		if p not in cells:
			cells.append(p)
		x = x+constants.DX*math.cos(th)
		y = y+constants.DX*math.sin(th)
	p = coord2grid(C, x, y)
	if p not in cells:
		cells.append(p)
	return cells