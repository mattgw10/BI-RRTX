import time
import csv

# Matthew Westbrook

# Print functions for logging data to csv files

def print_update(t_start, block_remove, block_add):
	# Print real-time changes
	with open('real_time.csv', 'a', newline='') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter = ',', quoting = csv.QUOTE_MINIMAL)
		spamwriter.writerow([0, time.time()-t_start])
		for cell in block_add:
			spamwriter.writerow([1, cell[0], cell[1]])
		for cell in block_remove:
			spamwriter.writerow([2, cell[0], cell[1]])

def print_map(v_loc, v_info, name):
	# Print current state of map
	with open(name, 'a', newline='') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter = ',', quotechar = '|', quoting = csv.QUOTE_MINIMAL)
		for i in range(0, len(v_info)):
			if not v_info[i][2] == -1:
				spamwriter.writerow([v_loc[i,0], v_loc[i,1], v_loc[v_info[i][2],0], v_loc[v_info[i][2],1]])
				
def print_robot_path(v_bot, v_loc, v_info):
	# Print robot path
	with open('robot_path.csv', 'a', newline='') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter = ',', quotechar = '|', quoting = csv.QUOTE_MINIMAL)
		p = v_info[v_bot][2]
		i = 1
		while not v_bot == -1 and i < 1000:
			spamwriter.writerow([v_loc[v_bot,0], v_loc[v_bot,1], v_loc[p,0], v_loc[p,1]])
			v_bot = p
			p = v_info[v_bot][2]
			i += 1
		spamwriter.writerow([-1,-1,-1,-1])
				
def print_grid(blocked, name):
	# Print current state of obstacles
	with open(name, 'a', newline='') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter = ',', quotechar = '|', quoting = csv.QUOTE_MINIMAL)
		for coord in blocked:
			spamwriter.writerow([coord[0], coord[1]])