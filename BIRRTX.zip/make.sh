#!/bin/sh

chmod +x BIRRTX.py