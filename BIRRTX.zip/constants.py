# Matthew Westbrook

# Constants

pi = 3.1415

# Radius of goal to terminate navigation
GOAL_RADIUS = 1

# Time step
DT = 0.1

# Forward speed
s = 5

# Sensing radius
R = 10

# Batch size of using my algorithm
m = 100

# Obstacle checking step
DX = 0.02

# Graph consistency
eps = 0.02

# Min size of neighbor ball
delta = 2

# Controls rate of neighbor ball decrease
lam = 6000
gamd = 1
D = 2
	