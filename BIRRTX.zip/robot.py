import time
import math
import numpy as np

import graph
import grid
import constants

# Matthew Westbrook

# Functions for robot motion
	
def try_to_start(v_loc, x, y, C, blocked, e_blocked, v_info, r, V, eoi, eoo, eri, ero, v_cell, e_cell, Q, v_orphan):
	# See if robot is connected to root of tree (neccessary to start)
	to_start = grid.nearest([x, y], v_loc)
	if grid.ed(v_loc[to_start,0], v_loc[to_start,1], x, y) < constants.delta:
		[success, v_loc] = graph.extend(C, blocked, e_blocked, [x, y], v_loc, v_info, r, V, eoi, eoo, eri, ero, v_cell, e_cell)
		if success:
			graph.rewire_neighbors(Q, V, v_info, r, eoi[V], eri[V], ero[V])
			graph.reduce_inconsistency(Q, V, v_info, eoi, eri, eoo, ero, r, v_orphan)
			return [True, v_loc]
	return [False, v_loc]

def update_bot(movement_start, movement_time, v_bot, eri, p, v_loc, v_info, x, y, th):
	# Update location of bot and determine if at next vertex
	
	t_past = time.time()-movement_start
	
	if t_past > movement_time:
		t_extra = t_past-movement_time
		v_bot = p
		p = v_info[v_bot][2]
		movement_start = time.time()-t_extra
		movement_time = grid.ed(v_loc[v_bot,0], v_loc[v_bot,1], v_loc[p,0], v_loc[p,1])/constants.s
		th = grid.angle(v_loc[v_bot,0], v_loc[v_bot,1], v_loc[p,0], v_loc[p,1])
		x = v_loc[v_bot,0]+math.cos(th)*constants.s*t_extra
		y = v_loc[v_bot,1]+math.sin(th)*constants.s*t_extra
	else:
		x = v_loc[v_bot,0]+math.cos(th)*constants.s*t_past
		y = v_loc[v_bot,1]+math.sin(th)*constants.s*t_past
	return [v_bot, p, x, y, th, movement_start, movement_time]
	