#!/bin/sh

python3 BIRRTX.py $@